
class BomNotesPage {
    createDialogBox() {
        cy.get('[data-cy="bom-notes-create-button"]').click();
    }

    filldetails(templatecode, testcode, analystNotes) {
        cy.get('[name="templateCode"]').click().type(`${templatecode}{enter}`);
        cy.get('[name="testCode"]').click().type(`${testcode}{enter}`);
        cy.get('[name="bomAnalystNotes"]').click().type(`${analystNotes}{enter}`);
    }

    clickCreateBtn() {
        cy.get('[data-cy="bom-notes-submit-button"]').click();
    }

    searchAndClick() {
        cy.get('[data-cy="bom-notes-search-field"]').type('search-term');
        cy.get('[data-cy="bom-notes-result-row"]').first().click();
    }

    clickPencilIcon() {
        cy.get('[data-cy="bom-notes-Edit-Icon"]').click();
    }

    updateBomNotesText(updatedText) {
        cy.get('textarea[name="bomAnalystNotes"]')
            .clear()
            .type(updatedText);
        cy.get('[data-cy="bom-notes-Edit-submit-button"]').click();
    }

    clickTrashIcon() {
        cy.get('[data-cy="bom-notes-Delete-Icon"]').click();
    }

    getAlertMessageElement() {
        return cy.get('div.MuiAlert-message');
    }

    getValidationMessageElement() {
        return cy.get('[data-cy="validation-message"]');
    }
}

export default new BomNotesPage();
