const { Given, When, Then } = require("cypress-cucumber-preprocessor/steps");
import bomNotesPage from "../../../pom/pages/BomNotesPage";
let templatecode = 'GRULE'
let testcode = 'ATC1'
let analystNotes = 'Automation testing notes added'

When("I create BOM Notes using valid inputs", () => {
  bomNotesPage.createDialogBox();
  bomNotesPage.filldetails(templatecode, testcode, analystNotes);
});

Then("a success message should be displayed for BOM Notes creation", () => {
  bomNotesPage.getAlertMessageElement()
    .should('be.visible')
    .invoke('text')
    .then((text) => {
      expect(text.trim()).to.include('BOM Notes created successfully');
    });
});
