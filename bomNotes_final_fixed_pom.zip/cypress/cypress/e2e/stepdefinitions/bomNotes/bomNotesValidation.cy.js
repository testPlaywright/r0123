const { Given, When, Then } = require("cypress-cucumber-preprocessor/steps");
import bomNotesPage from "../../../pom/pages/BomNotesPage";

When("I validate the BOM Notes using valid inputs", () => {
  bomNotesPage.createDialogBox();
  bomNotesPage.clickCreateBtn();
});

Then("the BOM Notes validation should complete successfully", () => {
  bomNotesPage.getValidationMessageElement()
    .should('be.visible')
    .and('contain.text', 'Validation completed successfully');
});
