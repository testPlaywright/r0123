const { Given, When, Then } = require("cypress-cucumber-preprocessor/steps");
import bomNotesPage from "../../../pom/pages/BomNotesPage";
let updatedText = 'UpdatedNotes####Automation testing notes added'

When("I edit BOM Notes using valid inputs", () => {
  bomNotesPage.searchAndClick();
  bomNotesPage.clickPencilIcon();
  bomNotesPage.updateBomNotesText(updatedText);
});

Then("a success message should be displayed for BOM Notes update", () => {
  bomNotesPage.getAlertMessageElement()
    .should('be.visible')
    .invoke('text')
    .then((text) => {
      expect(text.trim()).to.include('BOM Notes updated successfully');
    });
});
