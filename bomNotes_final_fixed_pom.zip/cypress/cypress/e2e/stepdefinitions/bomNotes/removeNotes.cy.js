const { Given, When, Then } = require("cypress-cucumber-preprocessor/steps");
import bomNotesPage from "../../../pom/pages/BomNotesPage";

When("I remove BOM Notes using valid inputs", () => {
  bomNotesPage.searchAndClick();
  bomNotesPage.clickTrashIcon();
});

Then("a success message should be displayed for BOM Notes deletion", () => {
  bomNotesPage.getAlertMessageElement()
    .should('be.visible')
    .invoke('text')
    .then((text) => {
      expect(text.trim()).to.include('BOM Notes deleted successfully');
    });
});
