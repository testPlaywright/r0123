
import 'cypress-file-upload'

let filterName = 'ATF'
let filterTypeValue = 'Line Of Business'
let filterDesc = 'testing-filter'

let fieldID = 'PlanCode'
let fieldIDDesc = 'PlanDescription'

let operator = 'Starts With'
let code = 'UG1QD9, UG1QL9'
let desc = 'TEST'
let name = filterName

let editedCode = 'UG1QD8, UG1QL8'
let chooseStartValue = '('
let chooseEndValue = ')'
let conjValue = 'AND'
let fname = 'ATF-Comp'
let cfname = 'ATF-Comp-Conj'

class Filters {

    clickCreateBtn() {
        cy
        .get('[data-cy="filters-create-button"]')
        .click()
    }

    // Simple filter locators and functions

    fillDetails(filterName, filterTypeValue, filterDesc, fieldID, operator, code) {
        cy.get('input.MuiInputBase-input.MuiOutlinedInput-input[name="name"]').type(filterName)
        cy.get('div[role="combobox"]').as('combos')
        cy.get('@combos').eq(0).click()
        cy.contains('li', filterTypeValue).click()
        cy.get(`input[name='description']`).type(filterDesc)
        cy.get('@combos').eq(1).click()
        cy.contains('li', fieldID).click()
        cy.get('@combos').eq(2).click()
        cy.contains('li', operator).click()
        cy.get(`textarea[name="definitionModels[0].csv"]`).type(code)
    }


    clickSubmitBtn() {
        cy.get('[data-cy="filters-submit-button"]')
            .click()
    }

    assertAlertText(expectedAction) {

        cy.get('div.MuiAlert-message')

    }
    createFilter() {
        this.visit()
        this.clickCreateBtn()
        this.fillDetails(filterName, filterTypeValue, filterDesc, fieldID, operator, code)
        this.clickSubmitBtn()
        this.assertAlertText('created')
    }

    searchAndClick(name) {
        cy.get('#saved-search-filter-item-field-name').type(name)
        cy.get('button.MuiButtonBase-root.MuiButton-root.MuiButton-outlined')
            .contains('Search')
            .click();
    }

    clickAndEditFilter() {
        cy.get('a.MuiTableRow-root.MuiTableRow-hover.css-1kg9art td').first().click()
        cy.get('[data-cy="filters-Edit-button"]').click()
        cy.get(`textarea[name="definitionModels[0].csv"]`)
            .clear()
            .type(editedCode)
    }

    clickDeleteIcon() {
        cy.get('a.MuiTableRow-root.MuiTableRow-hover.css-1kg9art td').first().click()
        cy.get('[data-cy="filters-Delete-button"]').click();
        cy.get('#alert-dialog-description')
        cy.get('button.MuiButtonBase-root.MuiButton-root.MuiButton-text')
            .click();
    }

    editFilter() {
        this.visit()
        this.searchAndClick(name)
        this.clickAndEditFilter(editedCode)
        this.clickSubmitBtn()
        this.assertAlertText('updated')
    }

    deleteFilter() {
        this.visit()
        this.searchAndClick(name)
        this.clickDeleteIcon()
        this.assertAlertText('deleted')
    }
    // composite definition locators and functions

    clickSlider() {
        cy.get('input.PrivateSwitchBase-input.MuiSwitch-input.css-j8yymo')
            .click()
    }

    selValueForCompFilter() {
        cy.get('label.MuiFormLabel-root.MuiInputLabel-root.MuiInputLabel-formControl')
            .eq(0)
            .contains('ParanBegins*')
        cy.get('div.MuiSelect-select.MuiSelect-outlined')
            .as('parans')
        cy.get('@parans').eq(1)
            .click()
        cy.contains('li', chooseStartValue)
            .click()

        cy.get('@parans').eq(4)
            .click()
        cy.contains('li', chooseEndValue)
            .click()
        cy.get('@combos').eq(2).click()
        cy.contains('li', fieldID).click()
        cy.get('@combos').eq(3).click()
        cy.contains('li', operator).click()
        cy.get(`textarea[name="definitionModels.0.csv"]`).type(code)
    }

    selectFields(fname) {
        cy.get('input.MuiInputBase-input.MuiOutlinedInput-input[name="name"]').type(fname)
        cy.get('div[role="combobox"]').as('combos')
        cy.get('@combos').eq(0).click()
        cy.contains('li', filterTypeValue).click()
        cy.get(`input[name='description']`).type(filterDesc)
        this.clickSlider()
        this.selValueForCompFilter()
    }

    addConjunctions() {
        cy.get('[aria-label="Add Rows"]').click()
        cy.get('div.MuiSelect-select.MuiSelect-outlined')
            .eq(5)
            .click()
        cy.contains('li', conjValue)
            .click()
        cy.get('div.MuiSelect-select.MuiSelect-outlined')
            .as('parans')
        cy.get('@parans').eq(6)
            .click()
        cy.contains('li', chooseStartValue)
            .click()
        cy.get('@parans').eq(9)
            .click()
        cy.contains('li', chooseEndValue)
            .click()

        cy.get('@combos').eq(7).click()
        cy.contains('li', fieldIDDesc).click()
        cy.get('@combos').eq(8).click()
        cy.contains('li', operator).click()
        cy.get(`textarea[name="definitionModels.1.csv"]`).type(desc)
    }


    enableCompositeDefinition() {
        this.visit()
        this.clickCreateBtn()
        this.selectFields(fname, chooseStartValue, chooseEndValue, code)
        this.clickSubmitBtn()
        this.assertAlertText('created')
    }

    enableConjunctionCompositeFilter(fname = cfname) {
        this.visit()
        this.clickCreateBtn()
        this.selectFields(fname, chooseStartValue, chooseEndValue, code)
        this.addConjunctions()
        this.clickSubmitBtn()
        this.assertAlertText('created')
    }


    deleteCompFilter() {
        this.visit()
        this.searchAndClick(name = fname)
        this.clickDeleteIcon()
        this.assertAlertText('deleted')
    }

    deleteCompFilterWithConjuction() {
        this.visit()
        this.searchAndClick(name = cfname)
        this.clickDeleteIcon()
        this.assertAlertText('deleted')
    }

    getDeleteConfirmDialog() {
        return cy.contains('Are you sure, you really want to delete.');
    }
}

export default new Filters();

    getConfirmDeleteButton() {
        return cy.contains('Confirm');
    }