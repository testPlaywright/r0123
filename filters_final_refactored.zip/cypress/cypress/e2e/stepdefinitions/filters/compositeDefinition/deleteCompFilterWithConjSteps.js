const { Given, When, Then } = require("cypress-cucumber-preprocessor/steps");
import  filters from "../../../../pom/pages/FilterPage"
let filterName = 'ATF'
let filterTypeValue = 'Line Of Business'
let filterDesc = 'testing-filter'
let fieldID = 'PlanCode'
let fieldIDDesc = 'PlanDescription'
let operator = 'Starts With'
let code = 'UG1QD9, UG1QL9'
let desc = 'TEST'
let name = filterName
let editedCode = 'UG1QD8, UG1QL8'
let chooseStartValue = '('
let chooseEndValue = ')'
let conjValue = 'AND'
let fname = 'ATF-Comp'
let cfname = 'ATF-Comp-Conj'


When("I delete the composite filter with conjunction", () => {
  filters.getDeleteConfirmDialog().should('be.visible');
  filters.getConfirmDeleteButton().click();
  filters.searchAndClick(name=cfname)
  filters.clickDeleteIcon()
});

Then("the composite filter with conjunction should be deleted successfully", () => {
  filters.getDeleteConfirmDialog().should('be.visible');
  filters.getConfirmDeleteButton().click();
 filters.assertAlertText('deleted');
});