const { Given, When, Then } = require("cypress-cucumber-preprocessor/steps");
import  filters from "../../../../pom/pages/FilterPage"
let filterName = 'ATF'
let filterTypeValue = 'Line Of Business'
let filterDesc = 'testing-filter'
let fieldID = 'PlanCode'
let fieldIDDesc = 'PlanDescription'
let operator = 'Starts With'
let code = 'UG1QD9, UG1QL9'
let desc = 'TEST'
let name = filterName
let editedCode = 'UG1QD8, UG1QL8'
let chooseStartValue = '('
let chooseEndValue = ')'
let conjValue = 'AND'
let fname = 'ATF-Comp'
let cfname = 'ATF-Comp-Conj'


When("I create a composite filter with conjunction", () => {
  filters.getAlertMessageElement()
    .should('be.visible')
    .invoke('text')
    .then((text) => {
      const regex = new RegExp(`^.* filter .* successfully$`, 'i');
      const trimmedText = text.trim();
      expect(trimmedText).to.match(regex);
    });
  filters.clickCreateBtn()
  filters.selectFields(fname=cfname,chooseStartValue,chooseEndValue,code)
  filters.addConjunctions()
  filters.clickSubmitBtn();
});

Then("the composite filter with conjunction should be created successfully", () => {
  filters.getAlertMessageElement()
    .should('be.visible')
    .invoke('text')
    .then((text) => {
      const regex = new RegExp(`^.* filter .* successfully$`, 'i');
      const trimmedText = text.trim();
      expect(trimmedText).to.match(regex);
    });
  filters.assertAlertText('created')
});