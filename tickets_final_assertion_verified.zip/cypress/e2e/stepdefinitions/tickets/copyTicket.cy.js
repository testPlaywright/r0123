import ticketsPage from "../../../pom/pages/TicketsPage"
const filename = Cypress.env("uploadFileName")

When("I enter the ticket ID and click on Search button", () => {
  ticketsPage.updateTicketFlow().then(() => {
    ticketsPage.searchTicketID();
  });
});

Then("I should be able to click on Copy and a duplicate ticket should be created successfully", () => {
  ticketsPage.clickSearchedTicket();
  ticketsPage.clickCopyButton();
  ticketsPage.uploadFile(filename);
  ticketsPage.clickCopyBtnInPrompt();
  ticketsPage.getAlertMessageElement()
    .should('be.visible')
    .invoke('text')
    .then((text) => {
      expect(text.trim()).to.include('Ticket Copied Successfully');
    });
});
